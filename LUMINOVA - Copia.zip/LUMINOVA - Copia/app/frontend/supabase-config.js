/* Configuração pública do Supabase para o frontend do LumiNova.
   Use a Project URL e a chave publicável/anon do projeto. NUNCA coloque service_role aqui. */
window.LUMINOVA_SUPABASE_CONFIG = {
  url: "https://vrxlbywhmgohdqbxihpw.supabase.co",
  anonKey: "sb_publishable_8LriLyYICcEpIN22OSoevw_O1CLwkEp",
};
